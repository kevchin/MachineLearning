a <- c("one","",NA)
nzchar(a)
