measured <- ts(1:10,start=1.0,end=2.0)
measured
start(measured)
end(measured)
frequency(measured)
