trial <- read.csv("trialTable.dat",header=FALSE,sep=' ')
trial
typeof(trial)
