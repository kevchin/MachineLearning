a <- "Ladislaus Bortkiewicz"
loc <- gregexpr("s",a)
loc[[1]]
length(loc[[1]])
