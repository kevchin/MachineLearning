x <- c(10,20,30,40)
dchisq(x,df=20)
