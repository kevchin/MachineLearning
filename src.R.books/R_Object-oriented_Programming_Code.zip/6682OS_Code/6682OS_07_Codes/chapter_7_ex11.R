thingAdd <- function(a)
{
    a + 1
}
thingAdd
