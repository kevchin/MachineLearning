trial <- read.fwf('trialFWF.dat',c(3,-5,2,4),skip=1)
trial
