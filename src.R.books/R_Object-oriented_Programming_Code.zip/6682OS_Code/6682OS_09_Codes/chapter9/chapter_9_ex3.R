source('antActivity.R')

ant3 <- Ant(Length=5.0,Position=c(3.0,2.0,1.0))
ant3
