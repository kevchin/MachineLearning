for(lupe in seq(1,2,by=0.33))
{
   cat("The value of lupe is ",lupe,"\n")
}
