C <- matrix(1:12,ncol=3)
C
dim(C)
dim(C) <- c(3,4)
C
