trial <- read.table("trialTable.dat")
trial
typeof(trial)
names(trial)
