source('chapter_8_ex4.R')
source('chapter_8_ex5.R')
source('chapter_8_ex6.R')
source('chapter_8_ex8.R')
source('chapter_8_ex9.R')
source('chapter_8_ex10.R')

simulateGeometric(oneDie)
simulateGeometric(oneDie)

simulateGeometric(oneCoin)
simulateGeometric(oneCoin,TRUE)


