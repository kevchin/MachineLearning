source('antActivity.R')

ant1 <- new("Ant")
ant1

