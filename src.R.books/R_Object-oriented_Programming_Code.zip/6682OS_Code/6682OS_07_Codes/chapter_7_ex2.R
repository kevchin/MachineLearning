if(1>2) {
   cat("One is the most biggest number\n")  # Say something wrong.
} else {
   cat("One is the loneliest number\n")     # Say something less wrong
}
