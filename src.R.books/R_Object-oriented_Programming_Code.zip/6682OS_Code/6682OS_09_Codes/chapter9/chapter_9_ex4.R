source('antActivity.R')

ant4 <- Ant(Length=-1.0,Position=c(3.0,2.0,1.0))
ant4

