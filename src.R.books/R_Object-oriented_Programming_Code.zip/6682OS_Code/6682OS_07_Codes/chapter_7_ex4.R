x <- c(1,2)
if(x < 2) {
  cat("Oh yes it is\n")
}

if(x > 1) {
  cat("Oh no it ain't")
}


                
