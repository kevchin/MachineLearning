a <- c(1,2,3)
b <- c(1,2,3)
mapply(sum,a,b)
