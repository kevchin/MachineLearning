#example 13
sub("\\?.*$","",urls)

