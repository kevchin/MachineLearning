a <- c(1,2,3,4,5,6)
A <- array(a,c(2,3))
A
t(A)
