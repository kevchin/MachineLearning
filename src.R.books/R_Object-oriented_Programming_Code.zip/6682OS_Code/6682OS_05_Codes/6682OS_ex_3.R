#example 3
nchar(c("one",NA,1234))
nchar(as.factor(c("a","b","a","a","b","c")))

