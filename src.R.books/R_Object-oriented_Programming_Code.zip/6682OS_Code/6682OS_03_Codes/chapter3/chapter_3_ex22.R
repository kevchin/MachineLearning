one <- 2
three <- exp(1)
out <- paste(one,three)
out
typeof(out)
out <- paste(one,three,sep="/")
out

