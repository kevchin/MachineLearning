x <- c(10,20,30,40)
pchisq(x,df=20)
