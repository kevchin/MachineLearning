x <- c(1,3,5,7)
x
x[1]
x[3]
length(x)
