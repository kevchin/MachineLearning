source('coordinateClass.R')


point <- Coordinate(x=1,y=5)
print(point)
point
