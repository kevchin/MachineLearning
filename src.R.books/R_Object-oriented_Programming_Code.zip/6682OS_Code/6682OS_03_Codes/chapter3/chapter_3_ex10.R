inventories = read.table("inventories.csv",skip=6,header=TRUE,sep=",")
inventories
typeof(inventories)
names(inventories)
inventories$X1994.1
