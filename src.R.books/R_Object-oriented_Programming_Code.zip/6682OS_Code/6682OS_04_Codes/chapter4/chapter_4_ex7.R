x <- c(5,10,15,20)
ppois(x,lambda=10)
