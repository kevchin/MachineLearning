a <- sprintf("%03d is the bestest %s evah!\n",9,"prime")
a
