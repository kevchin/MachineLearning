a = as.factor(c("a","b","a","c","b","a"))
b = as.factor(c("z","x","z","y","z","z"))
twoTab <- table(a,b)
twoTab
