x <- scan()
x
