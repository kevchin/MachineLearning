thing <- list(a=c(1,2,3),b=TRUE)
thing
attributes(thing)
