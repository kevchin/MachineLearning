x <- c(1,3,5,7)
sample(x,size=2)
sample(x,size=3)
sample(x,size=8)
