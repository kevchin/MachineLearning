three <- exp(1)
nice <- format(three,digits=2)
nice
nice <- format(three,digits=12)
nice
nice <- format(three,digits=3,width=5,justify="right")
nice
nice <- format(three,digits=3,width=8,justify="right",decimal.mark="#")
nice
