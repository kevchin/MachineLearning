v <- 1:5
v
l <- c(TRUE,FALSE,TRUE,FALSE,TRUE)
l
v[l]
v[!l] = -2
v
v[(1:5)>3]
