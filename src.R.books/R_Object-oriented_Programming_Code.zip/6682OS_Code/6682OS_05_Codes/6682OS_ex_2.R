#example 2
nchar(urls)

