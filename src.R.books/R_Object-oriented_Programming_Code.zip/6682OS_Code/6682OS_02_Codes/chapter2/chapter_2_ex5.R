one <- 1:5
two <- c(TRUE,FALSE)
three <- 4+5i
l <- list(first=one,second=two,third=three)
l
l$first
l$first[1]
l$second
l$third
l$third[1]
l$second[2]
