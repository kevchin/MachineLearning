source('chapter_8_ex8.R')

coin <- Coin()
coin <- simulation(coin)
getHistory(coin)
coin <- simulation(coin)
getHistory(coin)


die <- Die()
die <- simulation(die)
getHistory(die)
die <- simulation(die)
getHistory(die)
