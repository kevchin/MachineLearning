lupe <- 1.0
repeat {
    cat("The value of lupe is ",lupe,"\n")
    lupe <- lupe + 0.33
    if(lupe >= 2.0)
       break
}
