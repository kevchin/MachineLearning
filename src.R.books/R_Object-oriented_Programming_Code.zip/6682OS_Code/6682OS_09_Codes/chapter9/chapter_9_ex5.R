source('antActivity.R')

adomAnt <- Ant(Length=5.0,Position=c(-1.0,2.0,1.0))
adomAnt@Length
adomAnt@Position
adomAnt@ActivityLevel = -5.0
adomAnt@ActivityLevel
