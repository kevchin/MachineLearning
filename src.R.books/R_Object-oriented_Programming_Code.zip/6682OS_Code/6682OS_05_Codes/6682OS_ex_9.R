#example 9
chartr("=+","# ",urls)

