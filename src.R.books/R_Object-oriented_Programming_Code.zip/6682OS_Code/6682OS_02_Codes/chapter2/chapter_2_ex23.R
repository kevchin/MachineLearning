v <- c(1,2,3,NA,4,NA)
v
v[is.na(v)]
v[!is.na(v)]
