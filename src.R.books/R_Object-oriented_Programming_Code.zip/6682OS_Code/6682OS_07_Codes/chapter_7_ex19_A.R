updatePosition <- function(currentPos,angle=0.0,dist=c("uniform","normal"))
    {
        dist <- match.arg(dist)
        print(dist)
        # Update position code would go below
    }

updatePosition(0.0,0.0)
updatePosition(0.0,0.0,"uniform")
updatePosition(0.0,0.0,"neither")
