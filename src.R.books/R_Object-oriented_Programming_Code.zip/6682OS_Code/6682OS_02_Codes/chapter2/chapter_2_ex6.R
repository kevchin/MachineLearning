stuff <- list(ein=c(1,2,3),zwei=c(2+3i,1-1i));
stuff
names(stuff)
names(stuff) <- c("one","two")
stuff
stuff$one[1:2]
