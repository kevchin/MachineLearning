a <- "Ladislaus Bortkiewicz"
loc <- gregexpr("Poisson",a)
loc
loc[[1]][1]
