a <- c("a long string","a short string","he man inc.")
substr(a,3,6)
