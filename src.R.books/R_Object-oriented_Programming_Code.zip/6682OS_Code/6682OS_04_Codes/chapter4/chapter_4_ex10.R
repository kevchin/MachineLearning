RNGkind()
RNGkind("Super-Duper")
RNGkind()
