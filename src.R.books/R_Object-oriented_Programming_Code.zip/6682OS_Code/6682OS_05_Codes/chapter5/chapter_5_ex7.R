a <- c("One","tWO")
b <- chartr("Ot","@#",a)
b
