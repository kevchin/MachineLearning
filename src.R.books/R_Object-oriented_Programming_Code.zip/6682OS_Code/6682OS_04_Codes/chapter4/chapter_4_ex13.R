x <- c(1,3,5,7)
sample(x)
