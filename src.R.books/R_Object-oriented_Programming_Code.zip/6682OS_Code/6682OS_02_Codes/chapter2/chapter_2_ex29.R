A <- matrix(1:12,nrow=3,byrow=TRUE)
A
apply(A,1,sum)
apply(A,2,sum)
