source('antActivity.R')
source('antActivityMethods.R')
source('femaleAnt.R')
source('workerAnt.R')
source('antInitializers.R')

worker <- WorkerAnt(Position=c(1,2,3),Length=5.6)
slotNames(worker)

