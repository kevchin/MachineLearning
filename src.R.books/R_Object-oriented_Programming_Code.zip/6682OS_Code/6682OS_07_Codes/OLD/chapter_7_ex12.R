thingAdd <- function(a)
{
    b ← a + 3
    a + 1
}

val <- thingAdd(3)
val
