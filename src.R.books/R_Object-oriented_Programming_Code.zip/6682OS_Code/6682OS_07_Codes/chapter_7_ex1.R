# check if 1 is less than 2
if(1<2)
   cat("one is smaller than two.\n")

if(2>1) {
   cat("But two is bigger yet.\n")
}
