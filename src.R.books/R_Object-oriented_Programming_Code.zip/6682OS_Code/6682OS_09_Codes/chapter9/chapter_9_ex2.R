source('antActivity.R')


ant2 <- new("Ant",Length=4.5)
ant2

