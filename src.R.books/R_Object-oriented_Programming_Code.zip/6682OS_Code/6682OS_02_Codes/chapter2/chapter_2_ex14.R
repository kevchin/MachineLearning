B <- matrix(1:12,nrow=3)
B
B <- matrix(1:12,nrow=3,byrow=TRUE)
B
