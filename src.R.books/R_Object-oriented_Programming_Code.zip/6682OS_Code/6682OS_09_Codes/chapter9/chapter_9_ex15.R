source('antActivity.R')
source('antActivityMethods.R')
source('femaleAnt.R')
source('workerAnt.R')
source('antInitializers.R')

getSlots("WorkerAnt")
