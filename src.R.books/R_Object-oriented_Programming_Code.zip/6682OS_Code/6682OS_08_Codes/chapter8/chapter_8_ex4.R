# This example was removed
