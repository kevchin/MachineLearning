d <- data.frame(reverse=c(4,3,2,1),
                theLevels=as.factor(c("a","b","a","b")),
                values=c(1.2,2.3,3.4,4.5))
d
d$reverse
d$theLevels[1]
summary(d)
