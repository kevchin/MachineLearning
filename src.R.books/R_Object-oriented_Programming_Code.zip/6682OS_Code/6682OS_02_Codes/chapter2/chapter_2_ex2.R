d <- double(5)
d
d[1] <- 1
d[2] <- 3
d
d[2]
