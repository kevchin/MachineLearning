sample(3)
sample(5)
sample(5.6)
