dir()
save.image("wholeShebang.RData")
dir()
