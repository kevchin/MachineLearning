a <- c("one","two","three")
grep("^t",a)
a[grep("^t",a)]
