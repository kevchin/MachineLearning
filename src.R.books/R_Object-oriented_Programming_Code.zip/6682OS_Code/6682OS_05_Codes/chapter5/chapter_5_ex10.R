x <- 1:3
y <- seq(1,2,by=0.5)
x
y
values <- sprintf("%2d %6.3f\n",y,x)
values
