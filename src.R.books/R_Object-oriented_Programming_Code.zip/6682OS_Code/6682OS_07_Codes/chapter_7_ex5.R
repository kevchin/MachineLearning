x <- c(FALSE,FALSE,TRUE)
y <- c(FALSE,TRUE,TRUE)
x|y
x||y
