measured <- ts(1:10,start=1.0,frequency=0.5)
measured
start(measured)
end(measured)
frequency(measured)
