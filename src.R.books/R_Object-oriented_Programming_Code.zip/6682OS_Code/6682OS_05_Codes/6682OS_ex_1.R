# Example 1
urls <- c("https://duckduckgo.com?q=Johann+Carl+Friedrich+Gauss",
          "https://search.yahoo.com/search?p=Jean+Baptiste+Joseph+Fourier",
          "http://www.bing.com/search?q=Isaac+Newton",
          "http://www.google.com/search?q=Brahmagupta")

