a <- c("one",NA,2)
nchar(a)
