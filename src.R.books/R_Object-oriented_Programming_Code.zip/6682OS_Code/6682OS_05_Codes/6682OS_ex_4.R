#example 4
fileTypes <- c("txt","","html","txt")
nzchar(fileTypes)
fileTypes[nzchar(fileTypes)]

