x <- scan("diameters.csv")
x
x[3]
