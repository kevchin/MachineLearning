if(1>2) {
   cat("One is the most biggest number\n")
} else {
   cat("One is the loneliest number\n")
}
