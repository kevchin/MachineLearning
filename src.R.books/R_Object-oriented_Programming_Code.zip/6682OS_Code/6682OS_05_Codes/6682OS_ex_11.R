#example 10
splitURL <- strsplit(urls,":")
splitURL
splitURL[[1]]
splitURL[[1]][2]


