a <- c("godel","strudel","bubba")
b <- sub("del$","ober",a)
b
