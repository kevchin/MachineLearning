if(0) {
   cat("Yes, that is FALSE.\n")
} else if (1) {
   cat("Yes that is TRUE\n")
} else {
   cat("Whatever")
}
