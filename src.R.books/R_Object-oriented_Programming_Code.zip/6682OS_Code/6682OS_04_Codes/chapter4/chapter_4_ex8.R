p <- c(0.3,0.5,0.95,0.99)
qpois(p,lambda=10)
