x <- c(5,10,15,20)
dpois(x,lambda=10)
