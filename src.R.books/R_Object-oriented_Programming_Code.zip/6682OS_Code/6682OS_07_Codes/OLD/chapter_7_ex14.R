biggerThing <- function(first,second)
   {
     if(first < second)
        {
          return(second)
        }
     return(first)
   }

biggerThing(2,4)
biggerThing(4,2)
