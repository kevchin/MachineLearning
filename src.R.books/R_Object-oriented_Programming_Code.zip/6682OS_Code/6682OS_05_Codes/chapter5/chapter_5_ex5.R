a <- c("a long string","a short string","he man inc.")
substr(a,3,6) <- c("short","ant","uman")
a
