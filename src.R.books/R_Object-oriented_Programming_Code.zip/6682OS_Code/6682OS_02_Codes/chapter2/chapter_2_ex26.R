d <- data.frame(one=c(1,2,3),two=as.factor(c("one","two","three")))
e <- data.frame(three=c(4,5,6),four=as.factor(c("vier","funf","sechs")))
newDataFrame <- cbind(d,e)
newDataFrame
