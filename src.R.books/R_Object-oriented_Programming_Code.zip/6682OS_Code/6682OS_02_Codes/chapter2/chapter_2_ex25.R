d <- data.frame(one=c(1,2,3),two=as.factor(c("one","two","three")))
e <- c("ein","zwei","drei")
newDataFrame <- cbind(d,third=e)
newDataFrame
