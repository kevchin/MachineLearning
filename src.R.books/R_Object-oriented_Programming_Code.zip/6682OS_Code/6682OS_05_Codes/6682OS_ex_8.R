#example 8
tolower(urls[1])
toupper(urls[2])

