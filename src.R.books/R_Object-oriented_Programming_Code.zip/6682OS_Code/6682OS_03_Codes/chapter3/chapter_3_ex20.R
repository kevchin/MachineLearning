one <- 2
two <- 3
numbers <- paste(one,two)
numbers
numbers <- paste(one,two,sep="/")
numbers
