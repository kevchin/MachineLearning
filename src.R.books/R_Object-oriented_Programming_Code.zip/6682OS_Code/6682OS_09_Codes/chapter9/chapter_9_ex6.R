source('antActivity.R')
source('antActivityMethods.R')

ant2 <- new("Ant",Length=4.5)
GetLength(ant2)

