A <- matrix(1:12,nrow=3,byrow=TRUE)
A
margin.table(A)
margin.table(A,1)
margin.table(A,2)
