lupe <- 1.0;
while(lupe <= 2.0)
{
    cat("The value of lupe is ",lupe,"\n")
    lupe <- lupe + 0.33
}
