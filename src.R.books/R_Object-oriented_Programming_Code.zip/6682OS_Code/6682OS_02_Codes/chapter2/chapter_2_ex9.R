a = as.factor(c("a","b","a","c","b","a"))
a
tabA <- table(a)
tabA
summary(tabA)
