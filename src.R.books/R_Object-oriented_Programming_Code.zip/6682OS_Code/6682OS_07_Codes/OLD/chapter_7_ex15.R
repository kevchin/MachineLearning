changeArgs <- function(arg1,arg2)
   {
      arg1 <- 3
      arg2 <- arg2 + 1
      arg2
   }

first <- 1
second <- 2
changeArgs(first,second)
first
second
