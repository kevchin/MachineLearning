a <- c("One","tWO")
low <- tolower(a)
low
up <- toupper(a)
up
