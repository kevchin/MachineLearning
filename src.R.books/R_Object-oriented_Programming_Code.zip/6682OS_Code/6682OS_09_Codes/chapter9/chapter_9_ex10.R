source('coordinateClassInitializer.R')

point <- Coordinate(x=2,y=3)
point

