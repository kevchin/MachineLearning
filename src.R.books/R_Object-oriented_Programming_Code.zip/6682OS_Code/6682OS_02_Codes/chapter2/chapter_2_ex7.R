myList <- list(odd=c(1,3,5),even=c(2,4,6,8),e=exp(1))
myList
myList[1]
myList[1:2]
part <- myList[1:2]
typeof(part)
part
theOdd <- myList[[1]]
typeof(theOdd)
theOdd
