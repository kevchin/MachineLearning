theList <- list(one=c(1,2,3),two=c(TRUE,FALSE,TRUE,TRUE))
meanResult <- sapply(theList,mean)
meanResult
typeof(meanResult)
