oneDie <- list(trials=character(0))
class(oneDie) <- "Die"

oneCoin <- list(trials=character(0))
class(oneCoin) <- "Coin"
