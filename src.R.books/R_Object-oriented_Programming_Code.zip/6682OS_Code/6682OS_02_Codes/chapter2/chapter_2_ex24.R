v <- c(1,2,3,NA,4,NA)
v
mean(v)
mean(v,na.rm=TRUE)
