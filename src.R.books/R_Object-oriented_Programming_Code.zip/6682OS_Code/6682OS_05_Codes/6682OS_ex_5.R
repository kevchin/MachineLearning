#example 5
colons <- regexpr(":",urls)
colons
colons[2]
colons[3]

