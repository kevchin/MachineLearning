1:5
10:14
a <- 3:7
a
b <- seq(3,5)
b
b <- seq(3,10,by=3)
b
typeof(b)
